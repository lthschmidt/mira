from utils.data_loader import prepare_data_seq
from utils import config
from model.trainer import Train_MIME
import torch
import torch.utils.data as data
from collections import deque
from transformers import pipeline
import os
os.environ["TRANSFORMERS_NO_FLAX"] = "1"


# === Инициализация ===
DIALOG_SIZE = 3

# Загружаем модель эмоций
classifier = pipeline(
    "sentiment-analysis",
    model="blanchefort/rubert-base-cased-sentiment",
    tokenizer="blanchefort/rubert-base-cased-sentiment"
)

# Функция для оценки эмоции
def analyze_emotion(text):
    try:
        result = classifier(text)[0]
        label_map = {"NEGATIVE": "neg", "POSITIVE": "pos", "NEUTRAL": "neu"}
        label = label_map.get(result["label"], result["label"])
        score = float(result["score"])
        # для модели нужен один показатель, подставляем как "compound"
        return {"compound": score if label != "neg" else -score}
    except:
        return {"compound": 0.0}

# === Dataset для одной сессии ===
class Dataset(data.Dataset):
    def __init__(self, data, vocab):
        self.vocab = vocab
        self.data = data
    def __len__(self):
        return 1
    def __getitem__(self, index):
        item = {}
        item["context_text"] = [x for x in self.data if x != "None"]
        X_dial = [config.CLS_idx]
        X_mask = [config.CLS_idx]
        for i, sentence in enumerate(item["context_text"]):
            tokens = sentence.split()
            X_dial += [self.vocab.word2index.get(word, config.UNK_idx) for word in tokens]
            spk = self.vocab.word2index["USR"] if i % 2 == 0 else self.vocab.word2index["SYS"]
            X_mask += [spk] * len(tokens)
        item["context"] = X_dial
        item["mask"] = X_mask
        item["len"] = len(X_dial)
        return item

def collate_fn(data, emotion_score):
    input_batch = torch.LongTensor([data[0]["context"]])
    input_mask = torch.LongTensor([data[0]["mask"]])
    if config.USE_CUDA:
        input_batch = input_batch.cuda()
        input_mask = input_mask.cuda()
    d = {
        "input_batch": input_batch,
        "input_lengths": torch.LongTensor([data[0]["len"]]),
        "mask_input": input_mask,
        "program_label": torch.LongTensor([9]),  # фиктивная метка программы
        "context_emotion_scores": [emotion_score]  # сюда пихаем эмоцию
    }
    if config.USE_CUDA:
        d["program_label"] = d["program_label"].cuda()
    return d

def make_batch(inp, vocab, emotion_score):
    d = Dataset(inp, vocab)
    loader = torch.utils.data.DataLoader(dataset=d, batch_size=1, shuffle=False, collate_fn=lambda x: collate_fn(x, emotion_score))
    return next(iter(loader))

# === Загрузка модели ===
data_loader_tra, data_loader_val, data_loader_tst, vocab, program_number = prepare_data_seq(batch_size=config.batch_size)

model = Train_MIME(vocab, decoder_number=program_number, model_file_path=config.saved_model_path, is_eval=True)
if config.USE_CUDA:
    model.cuda()
model = model.eval()

print('Start to chat')

context = deque(DIALOG_SIZE * ['None'], maxlen=DIALOG_SIZE)

# === Основной цикл общения ===
while True:
    msg = input(">>> ")
    if len(msg.strip()) == 0:
        continue

    context.append(msg.strip())

    # Анализируем эмоцию по текущему сообщению пользователя
    emotion_score = analyze_emotion(msg.strip())

    batch = make_batch(context, vocab, emotion_score)
    sent_g, _, _ = model.decoder_greedy(batch, max_dec_step=30)

    print(">>>", sent_g[0])

    context.append(sent_g[0])
